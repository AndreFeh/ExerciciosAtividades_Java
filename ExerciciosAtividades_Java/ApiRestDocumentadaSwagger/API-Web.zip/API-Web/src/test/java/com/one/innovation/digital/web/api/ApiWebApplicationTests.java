package com.one.innovation.digital.web.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
