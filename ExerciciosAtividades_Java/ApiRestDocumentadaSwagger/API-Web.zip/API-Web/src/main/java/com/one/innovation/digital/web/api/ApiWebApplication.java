package com.one.innovation.digital.web.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiWebApplication.class, args);
	}

}
